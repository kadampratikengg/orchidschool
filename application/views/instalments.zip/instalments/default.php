<?php $this->load->view('_includes/header');?>
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<h3 class="page-title">Instalments</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('dashboard'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><span>Instalments</span></li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase">Instalment Details</span>
						</div>
					</div>
					<div class="portlet-body">
						<?php if($this->session->flashdata("success_message")!=""){?>
		                <div class="Metronic-alerts alert alert-info fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
		                </div>
		              <?php }?>
		              <?php if($this->session->flashdata("error_message")!=""){?>
		                <div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
		                </div>
		              <?php }?>
		              
		              <?php if(validation_errors()!=""){?>
		                <div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
		                </div>
		              <?php }?>
						<div class="form-body">
							<div class="row">
								<div class="col-md-12">
									<h4 style="color: #777; font-size: 24px; margin-left: 15px;">
										Instalment Details
									</h4>
									<hr>
									<?php for($i = 0; $i<count($instalment_data); $i++){?>
										<div class="col-md-3">
											<h4 class="<?php echo isset($payment_data[$i])?"font-green-meadow":"font-blue-steel"?>" 
												style="font-weight:bold;font-size:20px;">
												Installment No. <?php echo $instalment_data[$i]['instalment_name'];?>
											</h4>
											<ul class="list-group">
												<li class="list-group-item">
													<strong>
														Rs.<?php echo $instalment_data[$i]['instalment_amount'];?>
													</strong>
												</li>
												<?php if(isset($payment_data[$i])){?>
	
													<li class="list-group-item">
														Paid Amount:
														<span class="pull-right">
															Rs.<?php echo $payment_data[$i]['paid_amount'];?>
															<?php if($payment_data[$i]['discount_amount']>0 || $payment_data[$i]['late_fee_amount']>0){?>
																<a href="javascript:;" data-toggle="popover" data-trigger="hover" data-placement="top" 
																	data-html="true" title="Fees Bifurcation" 
																		data-content="<?php echo $payment_data[$i]['discount_amount']>0?"<strong>Discount:</strong> Rs.".$payment_data[$i]['discount_amount']."<br />":""?> 
																			<?php echo $payment_data[$i]['late_fee_amount']>0?"<strong>Late Fees:</strong> Rs.".$payment_data[$i]['late_fee_amount']:""?>">
																	<i class="fa fa-info-circle" style="color:#068;"></i>
																</a>
															<?php }?>
														</span>
													</li>
													<li class="list-group-item"> Pay Date: 
														<span class="pull-right">
															<?php echo date('d-M-Y',strtotime(swap_date_format($payment_data[$i]['payment_date'])));?>
														</span> 
													</li>
													<li class="list-group-item"> 
														<a href="<?php echo base_url('instalments/download_receipt/'.$payment_data[$i]['payment_id']); ?>" class="btn green-meadow"> 
															<i class="fa fa-download"></i> Download Receipt
														</a>
													</li>  
												<?php }else{?>
													<li class="list-group-item"> Start Date: 
														<span class="font-green-meadow pull-right">
															<?php echo date('d-M-Y', strtotime(swap_date_format($instalment_data[$i]['start_date'])));?>
														</span> 
													</li>
													<li class="list-group-item"> Due Date: 
														<span class="font-red-soft pull-right">
															<?php echo date('d-M-Y', strtotime(swap_date_format($instalment_data[$i]['due_date'])));?>
														</span> 
													</li>  
													<li class="list-group-item"> 
														<?php 
															$current_date =  new DateTime(date('Y-m-d'));
															$start_date = new DateTime($instalment_data[$i]['start_date']);
															$interval = $current_date->diff($start_date);
															
														?>
														<a 
															<?php if($current_date>=$start_date) { ?>
																href="<?php echo base_url('instalments/download_challan/'.$instalment_data[$i]['student_id'].'/'.$instalment_data[$i]['standard_instalment_id']);?>"
															<?php }?> 
															class="btn blue-steel" style="font-size: 12px; width:50%;"
															<?php if($current_date<$start_date) echo "disabled = 'disabled'"; ?>> 
															<i class="fa fa-download"></i> Challan
														</a>
														<a 
															<?php if($current_date>=$start_date) { ?>
																href="<?php echo base_url('instalments/initiate_pay/'.$instalment_data[$i]['invoice_id']); ?>" 
															<?php }?>
															class="btn green-jungle pull-right" style="font-size: 12px; width:50%;"
															<?php if($current_date<$start_date) echo "disabled = 'disabled'"; ?>> 
															<i class="fa fa-credit-card"></i> Pay Online
														</a>
													</li>
												<?php }?>
											</ul>
										</div>
									<?php }?>
								</div>
								<p style="text-align: center;">Note: Instalment Fees payment option will be available between their respective dates.</p>
							</div>
						</div>
						<div class="Metronic-alerts alert alert-info fade in">
							<h3 style="color:black;">You can also make payments from Paytm</h3>
							<span style="color:black;">
								<b>Steps:</b><br/> 
								1. go to : <a href="https://paytm.com/education" target="blank">https://paytm.com/education</a><br/>
								2. Select Institute as The Orchid School<br/>
								3. Enter your child Admission No (Enrollment No)<br/>
								4. Proceed to Pay<br/><br/>
								* Please note that payments made through Paytm will take some time to reflect it in your account
							</span>
                		</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>

<?php
$data ['script'] = "instalments.js";
$data ['initialize'] = "pageFunctions.init();";
$this->load->view ( '_includes/footer', $data );
?>